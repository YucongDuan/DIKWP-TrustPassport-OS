# Roadmap

## v0.1

- Offline CLI
- Manifest evaluator
- Community badge
- Demo outputs

## v0.2

- Web dashboard
- Batch evaluation for multiple repositories
- Registry index generator
- Badge verification endpoint scaffold

## v0.3

- Official signing plugin
- GitHub Action integration
- SPDX / license scanner integration
- CITATION.cff validator

## v1.0

- Public registry
- Enterprise API
- Partner certification workflow
- Industry conformance packs
