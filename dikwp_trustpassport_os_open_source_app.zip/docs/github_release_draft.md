# GitHub Release Draft

## DIKWP TrustPassport OS v0.1.0

This release introduces a GitHub-ready open-source toolkit for DIKWP project provenance, attribution, conformance scoring, trust passport generation, and community registry preparation.

### Highlights

- Project manifest evaluator
- DIKWP TrustPassport JSON
- Trust scorecard
- SVG badge generation
- Public registry entry
- Citation pack
- Attribution gap report
- Partner onboarding checklist
- Commercial route brief
- Offline static boundary audit

### Why this matters

DIKWP is becoming an ecosystem. Ecosystems need attribution, trust passports, conformance scoring, public registries, and official badge workflows. This toolkit gives DIKWP-based projects a clear path to visibility and trust.
