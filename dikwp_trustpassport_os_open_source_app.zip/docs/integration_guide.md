# Integration Guide

## Add a TrustPassport to a DIKWP repo

1. Add project manifest under `trustpassport/project_manifest.json`.
2. Run `dikwp-trustpassport evaluate trustpassport/project_manifest.json --out trustpassport/out`.
3. Copy `trustmark_badge.svg` into README.
4. Add `citation_pack.md` and `public_registry_entry.json`.
5. Submit registry entry for official review.

## GitHub Action idea

Future versions can run TrustPassport automatically on pull requests and releases.

## Integration with other DIKWP apps

- ProofLedger: evidence source.
- AgentTrace: runtime audit source.
- IntentGuard: intent risk source.
- MemoryLedger: memory governance source.
- AICAP-Gateway: hardware protocol conformance source.
