# Architecture

DIKWP TrustPassport OS uses a layered design.

## Layer 1: Project Manifest

The project manifest records project identity, repository, license, DIKWP usage, citations, evidence assets, governance boundaries, commercial route and registry request.

## Layer 2: DIKWP Conformance Scoring

The evaluator measures:

- Attribution integrity
- DIKWP semantic depth
- Evidence ledger readiness
- Governance boundary completeness
- Conformance surface
- Benefit capture route
- Copycat resilience
- Registry readiness

## Layer 3: Trust Passport

The TrustPassport is a structured JSON object containing project identity, score items, trust level, attribution status, registry status, copycat risk, content hash, kill conditions and recovery conditions.

## Layer 4: Public Assets

Generated public assets include a badge, registry entry, citation pack and partner checklist.

## Layer 5: Official Registry Extension

The community edition is unsigned. An official registry can sign the content hash and issue an official certificate. This allows open-source reuse without giving away official identity.

## Layer 6: Commercial Programs

Official registry, partner certification, enterprise API, conformance audits and training form the commercial moat.
