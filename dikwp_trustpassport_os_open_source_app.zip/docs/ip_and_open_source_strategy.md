# IP and Open Source Strategy

This document is a strategic guide, not legal advice.

## Principle

If a project is open source, others can usually use, modify and redistribute the code according to the license. Therefore, the project should not rely on code secrecy as its only moat.

## What should be protected through ecosystem design

- Project name and certification mark.
- Official registry and certificate signature.
- Attribution and citation policy.
- Verified conformance benchmark.
- Public release history.
- Partner certification.
- Enterprise services.

## Recommended repo assets

- README.md with clear origin story.
- NOTICE with DIKWP / Yucong Duan attribution.
- CITATION.cff so GitHub can display citation metadata.
- LICENSE with explicit open-source terms.
- TRADEMARK_POLICY.md for official names and badges.
- registry/ directory for public entries.
- signed_badges/ generated only by official authority.

## Community vs official

Community projects can generate unsigned passports. Official projects require registry signing. This distinction allows wide adoption while preserving official value.
