from dikwp_trustpassport.models import ProjectManifest
from dikwp_trustpassport.evaluator import evaluate_manifest
from dikwp_trustpassport.static_audit import audit_source


def test_good_manifest_scores_registry_ready():
    m = ProjectManifest(
        project_id="p1",
        project_name="Good DIKWP Project",
        version="0.1",
        owner="Yucong Duan",
        repository_url="https://github.com/YucongDuan/example",
        claimed_dikwp_use=["data", "information", "knowledge", "wisdom", "purpose", "reliability", "evidence", "intent"],
        attribution={"yucong_duan": True, "dikwp_model": True, "notice": True, "citation": True},
        license="MIT",
        citations=[{"title": "DIKWP", "author": "Yucong Duan"}],
        evidence_assets=[{"type": "demo"}, {"type": "test"}, {"type": "schema"}, {"type": "ledger"}],
        conformance_claims=["audit", "intent", "evidence", "recovery", "identity", "authorization", "data classification", "marking", "capability"],
        governance={"kill_conditions": True, "recovery_conditions": True, "action_boundary": True, "privacy": True, "audit": True, "human_review": True},
        commercial_plan={"open_core": True, "official_registry": True, "certification": True, "training": True, "enterprise_support": True, "partner_program": True},
        registry_request={"request_public_registry": True, "requested_badge": "TP-L3", "maintainer_contact": "x", "verification_assets": ["README.md"]},
    )
    p = evaluate_manifest(m, {"min_attribution_score": 0.65})
    assert p.trust_score > 0.7
    assert p.copycat_risk == "low"


def test_copycat_manifest_has_high_risk():
    m = ProjectManifest(
        project_id="p2",
        project_name="Clone",
        version="0.1",
        owner="Unknown",
        description="Uses DIKWP Data Information Knowledge Wisdom Purpose and claims official certified guaranteed standard answer.",
        claimed_dikwp_use=["data", "purpose"],
        attribution={"yucong_duan": False, "dikwp_model": False, "notice": False, "citation": False},
        conformance_claims=["official certified", "guaranteed standard answer"],
    )
    p = evaluate_manifest(m, {"min_attribution_score": 0.65})
    assert p.copycat_risk in {"medium", "high"}
    assert p.attribution_status == "insufficient"


def test_static_audit_passes_src():
    report = audit_source("src")
    assert report["pass"]
