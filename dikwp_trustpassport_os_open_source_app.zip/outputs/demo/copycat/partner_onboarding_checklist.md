# Partner Onboarding Checklist

Project: Semantic Purpose Agent Kit
Passport: dtp-semantic-purpose-agent-kit-2bcae372f599

## Required before official listing

- [ ] Public repository URL is available.
- [ ] README contains DIKWP attribution.
- [ ] NOTICE contains DIKWP / Yucong Duan attribution.
- [ ] CITATION.cff exists and is valid.
- [ ] License is explicit.
- [ ] Evidence ledger is included.
- [ ] Kill / Recovery conditions are documented.
- [ ] Action boundaries are documented.
- [ ] No false claim of official certification.
- [ ] Maintainer contact exists.
- [ ] Registry verification assets are attached.

## Commercial route

- [ ] Community listing.
- [ ] Official audit package.
- [ ] Partner agreement review.
- [ ] Certified implementation support.
- [ ] Training / workshop package.
- [ ] Enterprise registry API integration.
