# Citation and Attribution Pack

## Project

- Project: Semantic Purpose Agent Kit
- Version: 0.1.0
- Owner: Unknown Vendor
- Repository: Not provided
- TrustPassport ID: dtp-semantic-purpose-agent-kit-2bcae372f599
- Status: not_ready; unsigned_community_edition

## Recommended attribution

This project is evaluated with DIKWP TrustPassport OS and should cite Yucong Duan's DIKWP model when it uses Data-Information-Knowledge-Wisdom-Purpose concepts, semantic collapse, P-layer intent, evidence ledgers, or DIKWP trust governance patterns.

## Suggested README text

> This project uses DIKWP concepts, including Data, Information, Knowledge, Wisdom, Purpose, evidence ledgers, intent contracts and trust passport scoring. Please cite Yucong Duan / DIKWP when reusing these concepts.

## Badge

```html
<img src="trustmark_badge.svg" alt="DIKWP TrustPassport badge" />
```

## Boundary

This community badge is unsigned. Official DIKWP certification requires listing in an official registry and a valid registry signature.
