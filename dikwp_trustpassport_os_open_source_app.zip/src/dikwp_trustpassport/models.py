from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


@dataclass
class ProjectManifest:
    project_id: str
    project_name: str
    version: str
    owner: str
    repository_url: str = ""
    description: str = ""
    claimed_dikwp_use: List[str] = field(default_factory=list)
    attribution: Dict[str, Any] = field(default_factory=dict)
    license: str = ""
    citations: List[Dict[str, str]] = field(default_factory=list)
    evidence_assets: List[Dict[str, Any]] = field(default_factory=list)
    conformance_claims: List[str] = field(default_factory=list)
    capabilities: List[str] = field(default_factory=list)
    prohibited_claims: List[str] = field(default_factory=list)
    governance: Dict[str, Any] = field(default_factory=dict)
    commercial_plan: Dict[str, Any] = field(default_factory=dict)
    registry_request: Dict[str, Any] = field(default_factory=dict)

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> "ProjectManifest":
        return ProjectManifest(**{k: data.get(k) for k in ProjectManifest.__dataclass_fields__.keys() if k in data})

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ScoreItem:
    name: str
    score: float
    weight: float
    rationale: str
    evidence: List[str] = field(default_factory=list)

    def weighted(self) -> float:
        return self.score * self.weight

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class TrustPassport:
    passport_id: str
    project_id: str
    project_name: str
    version: str
    owner: str
    trust_level: str
    trust_score: float
    score_items: List[ScoreItem]
    attribution_status: str
    registry_status: str
    signature_status: str
    copycat_risk: str
    recommendations: List[str]
    kill_conditions: List[str]
    recovery_conditions: List[str]
    content_hash: str

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["score_items"] = [x.to_dict() for x in self.score_items]
        return data
