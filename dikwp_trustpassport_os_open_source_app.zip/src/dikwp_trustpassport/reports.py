from __future__ import annotations

import csv
from pathlib import Path
from typing import Any, Dict, List
from .models import ProjectManifest, TrustPassport
from .text_utils import write_json, write_text


def _badge_color(score: float) -> str:
    if score >= 0.85:
        return "#1f7a1f"
    if score >= 0.70:
        return "#3b82f6"
    if score >= 0.55:
        return "#f59e0b"
    return "#ef4444"


def make_badge_svg(passport: TrustPassport) -> str:
    color = _badge_color(passport.trust_score)
    label = "DIKWP TrustPassport"
    value = f"{passport.trust_score:.2f} unsigned"
    width = 420
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="28" role="img" aria-label="{label}: {value}">
  <linearGradient id="s" x2="0" y2="100%">
    <stop offset="0" stop-color="#bbb" stop-opacity=".1"/>
    <stop offset="1" stop-opacity=".1"/>
  </linearGradient>
  <rect rx="4" width="{width}" height="28" fill="#555"/>
  <rect rx="4" x="180" width="{width-180}" height="28" fill="{color}"/>
  <rect rx="4" width="{width}" height="28" fill="url(#s)"/>
  <text x="90" y="18" fill="#fff" text-anchor="middle" font-family="Verdana,Arial" font-size="11">{label}</text>
  <text x="300" y="18" fill="#fff" text-anchor="middle" font-family="Verdana,Arial" font-size="11">{value}</text>
</svg>'''


def make_citation_pack(manifest: ProjectManifest, passport: TrustPassport) -> str:
    return f"""# Citation and Attribution Pack

## Project

- Project: {manifest.project_name}
- Version: {manifest.version}
- Owner: {manifest.owner}
- Repository: {manifest.repository_url or 'Not provided'}
- TrustPassport ID: {passport.passport_id}
- Status: {passport.registry_status}; {passport.signature_status}

## Recommended attribution

This project is evaluated with DIKWP TrustPassport OS and should cite Yucong Duan's DIKWP model when it uses Data-Information-Knowledge-Wisdom-Purpose concepts, semantic collapse, P-layer intent, evidence ledgers, or DIKWP trust governance patterns.

## Suggested README text

> This project uses DIKWP concepts, including Data, Information, Knowledge, Wisdom, Purpose, evidence ledgers, intent contracts and trust passport scoring. Please cite Yucong Duan / DIKWP when reusing these concepts.

## Badge

```html
<img src="trustmark_badge.svg" alt="DIKWP TrustPassport badge" />
```

## Boundary

This community badge is unsigned. Official DIKWP certification requires listing in an official registry and a valid registry signature.
"""


def make_partner_checklist(manifest: ProjectManifest, passport: TrustPassport) -> str:
    return f"""# Partner Onboarding Checklist

Project: {manifest.project_name}
Passport: {passport.passport_id}

## Required before official listing

- [ ] Public repository URL is available.
- [ ] README contains DIKWP attribution.
- [ ] NOTICE contains DIKWP / Yucong Duan attribution.
- [ ] CITATION.cff exists and is valid.
- [ ] License is explicit.
- [ ] Evidence ledger is included.
- [ ] Kill / Recovery conditions are documented.
- [ ] Action boundaries are documented.
- [ ] No false claim of official certification.
- [ ] Maintainer contact exists.
- [ ] Registry verification assets are attached.

## Commercial route

- [ ] Community listing.
- [ ] Official audit package.
- [ ] Partner agreement review.
- [ ] Certified implementation support.
- [ ] Training / workshop package.
- [ ] Enterprise registry API integration.
"""


def make_commercial_route(passport: TrustPassport) -> str:
    return f"""# Commercial Route Brief

## Strategic thesis

Open-source adoption should increase the value of the originator rather than erase it. The scarce layer is not a freely forkable algorithm; it is the official trust passport, registry, certification process, signed badge, evidence ledger reputation, and training ecosystem.

## Product tiers

1. **Community Edition**: free CLI, self-declared unsigned badge, local scorecard.
2. **Official Registry Listing**: public listing, registry ID, signed badge, conformance review.
3. **Certified Partner Program**: paid training, partner badge, review templates, sales enablement.
4. **Enterprise Trust API**: registry verification API, audit export, procurement-ready report.
5. **Industry Conformance Packs**: AICAP, education, health, law, transportation, manufacturing, finance.

## Why copying does not destroy the opportunity

A fork can copy code, but it cannot honestly copy an official registry signature, original release history, citation network, public standard authorship, partner program, or community trust identity.

## Current passport score

- Trust score: {passport.trust_score}
- Trust level: {passport.trust_level}
- Attribution status: {passport.attribution_status}
- Copycat risk: {passport.copycat_risk}
"""


def write_outputs(out_dir: str | Path, manifest: ProjectManifest, passport: TrustPassport) -> None:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    write_json(out / "trust_passport.json", passport.to_dict())
    scorecard = {
        "project_id": passport.project_id,
        "project_name": passport.project_name,
        "trust_score": passport.trust_score,
        "trust_level": passport.trust_level,
        "score_items": [x.to_dict() for x in passport.score_items],
        "recommendations": passport.recommendations,
    }
    write_json(out / "trust_scorecard.json", scorecard)

    # CSV scorecard for easy comparison.
    with open(out / "trust_scorecard.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["name", "score", "weight", "weighted", "rationale"])
        w.writeheader()
        for item in passport.score_items:
            w.writerow({"name": item.name, "score": item.score, "weight": item.weight, "weighted": round(item.weighted(), 4), "rationale": item.rationale})

    write_text(out / "trustmark_badge.svg", make_badge_svg(passport))
    registry_entry = {
        "registry_type": "community_self_declared",
        "official_signature_required": True,
        "passport_id": passport.passport_id,
        "project_id": passport.project_id,
        "project_name": passport.project_name,
        "version": passport.version,
        "owner": passport.owner,
        "content_hash": passport.content_hash,
        "trust_score": passport.trust_score,
        "trust_level": passport.trust_level,
        "repository_url": manifest.repository_url,
        "signature_status": passport.signature_status,
    }
    write_json(out / "public_registry_entry.json", registry_entry)
    write_text(out / "citation_pack.md", make_citation_pack(manifest, passport))
    gap_report = {
        "attribution_status": passport.attribution_status,
        "copycat_risk": passport.copycat_risk,
        "recommendations": passport.recommendations,
        "kill_conditions": passport.kill_conditions,
        "recovery_conditions": passport.recovery_conditions,
    }
    write_json(out / "attribution_gap_report.json", gap_report)
    write_text(out / "partner_onboarding_checklist.md", make_partner_checklist(manifest, passport))
    write_text(out / "commercial_route_brief.md", make_commercial_route(passport))
