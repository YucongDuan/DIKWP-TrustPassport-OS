from __future__ import annotations

import ast
from pathlib import Path
from typing import Dict, List

FORBIDDEN_IMPORTS = {"socket", "requests", "urllib", "httpx", "subprocess", "os", "shutil", "ftplib", "telnetlib"}
FORBIDDEN_CALLS = {"eval", "exec", "__import__", "open"}
ALLOWED_OPEN_CONTEXT = {"read_json", "write_json", "write_text"}


def audit_source(root: str | Path) -> Dict:
    root = Path(root)
    findings: List[Dict] = []
    for path in root.rglob("*.py"):
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except Exception as e:
            findings.append({"file": str(path), "type": "parse_error", "message": str(e)})
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    top = alias.name.split(".")[0]
                    if top in FORBIDDEN_IMPORTS:
                        findings.append({"file": str(path), "type": "forbidden_import", "name": alias.name})
            if isinstance(node, ast.ImportFrom) and node.module:
                top = node.module.split(".")[0]
                if top in FORBIDDEN_IMPORTS:
                    findings.append({"file": str(path), "type": "forbidden_import", "name": node.module})
            if isinstance(node, ast.Call):
                if isinstance(node.func, ast.Name) and node.func.id in {"eval", "exec", "__import__"}:
                    findings.append({"file": str(path), "type": "forbidden_call", "name": node.func.id})
    return {
        "pass": len(findings) == 0,
        "finding_count": len(findings),
        "findings": findings,
        "policy": "No network imports, subprocess, dynamic execution, hidden telemetry, host mutation, or real-world actuation helpers in the offline core."
    }
