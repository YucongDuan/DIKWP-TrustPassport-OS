from __future__ import annotations

import argparse
from pathlib import Path
from .models import ProjectManifest
from .evaluator import evaluate_manifest
from .reports import write_outputs
from .static_audit import audit_source
from .text_utils import read_json, write_json


def cmd_evaluate(args: argparse.Namespace) -> None:
    manifest_data = read_json(args.manifest)
    policy = read_json(args.policy) if args.policy else {"min_attribution_score": 0.65}
    manifest = ProjectManifest.from_dict(manifest_data)
    passport = evaluate_manifest(manifest, policy)
    write_outputs(args.out, manifest, passport)
    print(f"trust_score={passport.trust_score} trust_level={passport.trust_level} copycat_risk={passport.copycat_risk}")


def cmd_static_audit(args: argparse.Namespace) -> None:
    report = audit_source(args.root)
    write_json(args.out, report)
    print("PASS" if report["pass"] else "FAIL")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="dikwp-trustpassport")
    sub = p.add_subparsers(dest="command", required=True)
    e = sub.add_parser("evaluate", help="Evaluate a project manifest and generate a DIKWP TrustPassport.")
    e.add_argument("manifest")
    e.add_argument("--policy", default="configs/default_policy.json")
    e.add_argument("--out", default="outputs/demo")
    e.set_defaults(func=cmd_evaluate)
    a = sub.add_parser("static-audit", help="Run offline static boundary audit.")
    a.add_argument("root")
    a.add_argument("--out", default="outputs/demo/static_boundary_audit_report.json")
    a.set_defaults(func=cmd_static_audit)
    return p


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
