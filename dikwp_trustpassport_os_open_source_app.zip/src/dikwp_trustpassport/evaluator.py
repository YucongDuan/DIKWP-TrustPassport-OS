from __future__ import annotations

import hashlib
import json
from typing import Any, Dict, List, Tuple
from .models import ProjectManifest, ScoreItem, TrustPassport
from .text_utils import slugify


DIKWP_KEYWORDS = ["DIKWP", "Data", "Information", "Knowledge", "Wisdom", "Purpose", "D/I/K/W/P", "semantic", "intent"]
RISKY_OFFICIAL_TERMS = ["official", "certified", "endorsed", "authorized", "standard answer", "guaranteed", "唯一", "保证", "官方认证", "标准答案"]


def clamp01(v: float) -> float:
    return max(0.0, min(1.0, float(v)))


def _has_text(obj: Any, terms: List[str]) -> bool:
    text = json.dumps(obj, ensure_ascii=False).lower()
    return any(t.lower() in text for t in terms)


def _count_text(obj: Any, terms: List[str]) -> int:
    text = json.dumps(obj, ensure_ascii=False).lower()
    return sum(1 for t in terms if t.lower() in text)


def evaluate_manifest(m: ProjectManifest, policy: Dict[str, Any]) -> TrustPassport:
    items: List[ScoreItem] = []

    # 1. Attribution completeness.
    attrib = m.attribution or {}
    required_attrib = ["yucong_duan", "dikwp_model", "notice", "citation"]
    attrib_hits = sum(1 for k in required_attrib if attrib.get(k))
    citations_count = len(m.citations or [])
    attr_score = clamp01((attrib_hits / len(required_attrib)) * 0.75 + min(citations_count, 3) / 3 * 0.25)
    items.append(ScoreItem(
        "attribution_integrity", attr_score, 0.18,
        "Measures whether the project visibly attributes Yucong Duan / DIKWP and includes machine-readable citation metadata.",
        [f"attribution_fields={attrib_hits}/{len(required_attrib)}", f"citations={citations_count}"]
    ))

    # 2. DIKWP semantic layer presence.
    layers = [x.lower() for x in (m.claimed_dikwp_use or [])]
    layer_terms = ["data", "information", "knowledge", "wisdom", "purpose", "reliability", "evidence", "intent"]
    layer_hits = sum(1 for t in layer_terms if any(t in x for x in layers))
    semantic_score = clamp01(layer_hits / len(layer_terms))
    items.append(ScoreItem(
        "dikwp_semantic_depth", semantic_score, 0.14,
        "Measures whether the project implements more than slogan-level DIKWP layers.",
        [f"layer_hits={layer_hits}/{len(layer_terms)}"]
    ))

    # 3. Evidence assets.
    ev = m.evidence_assets or []
    ev_types = {str(e.get("type", "")).lower() for e in ev}
    evidence_score = clamp01(len(ev) / 6 * 0.6 + len(ev_types) / 4 * 0.4)
    items.append(ScoreItem(
        "evidence_ledger_readiness", evidence_score, 0.12,
        "Measures whether claims can be tied to evidence assets, source ledgers, tests or demos.",
        [f"evidence_assets={len(ev)}", f"evidence_types={sorted(ev_types)}"]
    ))

    # 4. Governance and boundary.
    gov = m.governance or {}
    gov_keys = ["kill_conditions", "recovery_conditions", "action_boundary", "privacy", "audit", "human_review"]
    gov_hits = sum(1 for k in gov_keys if gov.get(k))
    gov_score = clamp01(gov_hits / len(gov_keys))
    items.append(ScoreItem(
        "governance_boundary", gov_score, 0.12,
        "Measures whether the project includes boundaries, kill conditions, recovery and human review.",
        [f"governance_fields={gov_hits}/{len(gov_keys)}"]
    ))

    # 5. Conformance claims.
    claims = m.conformance_claims or []
    conformance_terms = ["audit", "intent", "evidence", "recovery", "identity", "authorization", "data classification", "marking", "capability"]
    conformance_hits = _count_text(claims, conformance_terms)
    conf_score = clamp01(conformance_hits / len(conformance_terms))
    items.append(ScoreItem(
        "conformance_surface", conf_score, 0.10,
        "Measures whether conformance claims cover a broad set of trust surfaces.",
        [f"conformance_hits={conformance_hits}/{len(conformance_terms)}"]
    ))

    # 6. Commercial route clarity.
    cp = m.commercial_plan or {}
    cp_keys = ["open_core", "official_registry", "certification", "training", "enterprise_support", "partner_program"]
    cp_hits = sum(1 for k in cp_keys if cp.get(k))
    cp_score = clamp01(cp_hits / len(cp_keys))
    items.append(ScoreItem(
        "benefit_capture_route", cp_score, 0.12,
        "Measures whether open-source adoption can still generate name, registry or service value for the originator.",
        [f"commercial_fields={cp_hits}/{len(cp_keys)}"]
    ))

    # 7. Copycat risk.
    uses_dikwp_terms = _has_text(m.to_dict(), DIKWP_KEYWORDS)
    lacks_attribution = attr_score < 0.55
    risky_official = _has_text(m.to_dict(), RISKY_OFFICIAL_TERMS)
    copycat_score = 0.0
    if uses_dikwp_terms and lacks_attribution:
        copycat_score += 0.55
    if risky_official:
        copycat_score += 0.25
    if not m.repository_url:
        copycat_score += 0.10
    if not m.license:
        copycat_score += 0.10
    copycat_score = clamp01(copycat_score)
    inverse_copycat_score = 1.0 - copycat_score
    items.append(ScoreItem(
        "copycat_resilience", inverse_copycat_score, 0.16,
        "Measures whether the project is unlikely to become an unattributed clone or false-certified derivative.",
        [f"copycat_risk_score={copycat_score:.3f}"]
    ))

    # 8. Registry readiness.
    rr = m.registry_request or {}
    rr_keys = ["request_public_registry", "requested_badge", "maintainer_contact", "verification_assets"]
    rr_hits = sum(1 for k in rr_keys if rr.get(k))
    rr_score = clamp01(rr_hits / len(rr_keys))
    items.append(ScoreItem(
        "registry_readiness", rr_score, 0.10,
        "Measures whether the project can enter a public DIKWP registry and badge workflow.",
        [f"registry_fields={rr_hits}/{len(rr_keys)}"]
    ))

    trust_score = round(sum(x.weighted() for x in items) / sum(x.weight for x in items), 4)

    if trust_score >= 0.85:
        trust_level = "TP-L4: high-confidence DIKWP trust passport candidate"
    elif trust_score >= 0.70:
        trust_level = "TP-L3: registry-ready candidate"
    elif trust_score >= 0.55:
        trust_level = "TP-L2: usable but attribution/conformance improvements needed"
    elif trust_score >= 0.35:
        trust_level = "TP-L1: weak passport; human review required"
    else:
        trust_level = "TP-L0: not registry-ready"

    if copycat_score >= 0.70:
        copycat_risk = "high"
    elif copycat_score >= 0.35:
        copycat_risk = "medium"
    else:
        copycat_risk = "low"

    attribution_status = "sufficient" if attr_score >= policy.get("min_attribution_score", 0.65) else "insufficient"
    registry_status = "community_self_declared" if rr_score >= 0.5 else "not_ready"
    signature_status = "unsigned_community_edition"

    recommendations: List[str] = []
    if attribution_status != "sufficient":
        recommendations.append("Add visible DIKWP / Yucong Duan attribution in README, NOTICE and CITATION.cff.")
    if evidence_score < 0.65:
        recommendations.append("Add evidence assets: demos, tests, source ledger, schema, conformance matrix or third-party references.")
    if gov_score < 0.65:
        recommendations.append("Add explicit action boundary, kill conditions, recovery path, audit and human review policy.")
    if rr_score < 0.5:
        recommendations.append("Add registry request metadata and verification assets before applying for official badge.")
    if copycat_risk != "low":
        recommendations.append("Treat this as copycat-risk: require attribution repair before any badge, partnership or listing.")
    if not recommendations:
        recommendations.append("Ready for community registry submission; official badge requires signature by the registry authority.")

    kill_conditions = [
        "False claim of official DIKWP certification without registry signature.",
        "Removal of DIKWP / Yucong Duan attribution while preserving DIKWP-derived branding.",
        "Unsupported claim that the project guarantees legal, medical, financial, safety or industrial compliance.",
        "Evidence ledger disabled or falsified.",
        "Official registry signature mismatch or revoked certificate."
    ]
    recovery_conditions = [
        "Restore attribution and citation metadata.",
        "Regenerate trust passport with updated evidence ledger.",
        "Downgrade badge to self-declared community level.",
        "Submit to human review for official registry listing.",
        "Publish a correction note for any over-claimed certification or endorsement."
    ]

    content_hash = hashlib.sha256(json.dumps(m.to_dict(), sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()
    passport_id = f"dtp-{slugify(m.project_name)}-{content_hash[:12]}"

    return TrustPassport(
        passport_id=passport_id,
        project_id=m.project_id,
        project_name=m.project_name,
        version=m.version,
        owner=m.owner,
        trust_level=trust_level,
        trust_score=trust_score,
        score_items=items,
        attribution_status=attribution_status,
        registry_status=registry_status,
        signature_status=signature_status,
        copycat_risk=copycat_risk,
        recommendations=recommendations,
        kill_conditions=kill_conditions,
        recovery_conditions=recovery_conditions,
        content_hash=content_hash,
    )
