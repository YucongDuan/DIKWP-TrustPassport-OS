from __future__ import annotations

import json

try:
    import streamlit as st
except Exception:  # pragma: no cover
    st = None

from .models import ProjectManifest
from .evaluator import evaluate_manifest


def main():  # pragma: no cover
    if st is None:
        raise RuntimeError("streamlit is not installed. Install with pip install -e .[app]")
    st.title("DIKWP TrustPassport OS")
    st.write("Paste a project manifest JSON to generate a community trust passport.")
    text = st.text_area("Project manifest", height=300)
    if st.button("Evaluate") and text.strip():
        manifest = ProjectManifest.from_dict(json.loads(text))
        passport = evaluate_manifest(manifest, {"min_attribution_score": 0.65})
        st.metric("Trust score", passport.trust_score)
        st.write(passport.trust_level)
        st.json(passport.to_dict())


if __name__ == "__main__":
    main()
