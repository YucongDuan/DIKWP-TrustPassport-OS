# Code of Conduct

This project is intended for constructive open-source collaboration. Contributors should respect attribution, avoid misrepresentation, and avoid using the project to create deceptive certification claims.
