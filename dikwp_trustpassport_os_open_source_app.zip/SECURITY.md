# Security Policy

The default core is offline-first and should not contain network calls, subprocess execution, dynamic code execution, hidden telemetry, or real-world actuation helpers.

Report suspected security issues through the future official DIKWP project contact channel.
