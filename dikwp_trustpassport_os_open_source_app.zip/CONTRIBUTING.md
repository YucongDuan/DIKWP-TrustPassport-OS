# Contributing

Contributions are welcome. Please keep the project aligned with these principles:

1. Preserve DIKWP attribution.
2. Do not claim official certification unless an official registry signature exists.
3. Do not add network calls, subprocess execution, dynamic code execution, or hidden telemetry to the default offline core.
4. Keep all conformance scoring explainable.
5. Treat legal, medical, financial, public-safety, and critical-infrastructure claims as high-risk.
